from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import gymnasium as gym
import numpy as np


@dataclass(frozen=True)
class TaskSpec:
    """Reusable task identity. Compatible tasks share obs/action semantics.

    CartPole-v1, Acrobot-v1, MountainCar-v0 and MountainCarContinuous-v0
    are *not* compatible: different observation sizes, action counts or
    dynamics. Do not transfer their states or weights.
    """

    task_id: str
    family: str
    gym_id: str
    obs_dim: int
    n_actions: int
    params: dict[str, float] = field(default_factory=dict)
    reward_scale: float = 1.0
    reward_offset: float = 0.0
    train_split: str = "train"
    notes: str = ""

    def normalized_reward(self, raw: float) -> float:
        return (float(raw) + self.reward_offset) * self.reward_scale

    def compatible_with(self, other: "TaskSpec") -> bool:
        return (
            self.family == other.family
            and self.obs_dim == other.obs_dim
            and self.n_actions == other.n_actions
            and self.gym_id == other.gym_id
        )


# Gymnasium 1.4 CartPoleEnv caches these at __init__. Changing mass/length
# without recomputing them leaves the Euler step on the default pole.
CARTPOLE_PHYSICS_VERSION = "cartpole_derived_v1"
CARTPOLE_PHYSICS_VERSION_LEGACY = "cartpole_setattr_only"


def sync_cartpole_derived(inner: Any) -> None:
    """Recompute CartPole quantities that Gymnasium derives in ``__init__``."""
    if hasattr(inner, "masscart") and hasattr(inner, "masspole"):
        inner.total_mass = inner.masscart + inner.masspole
    if hasattr(inner, "masspole") and hasattr(inner, "length"):
        inner.polemass_length = inner.masspole * inner.length


def apply_params(env: gym.Env, spec: TaskSpec) -> gym.Env:
    from nexus.tasks.wrappers import WRAPPER_PARAM_KEYS

    inner = env.unwrapped
    for key, value in spec.params.items():
        if key in WRAPPER_PARAM_KEYS:
            continue
        if not hasattr(inner, key):
            if spec.family == "mountaincar_continuous" and key == "gravity":
                setattr(inner, key, value)
                continue
            raise AttributeError(f"{spec.gym_id} has no attribute {key}")
        setattr(inner, key, value)
    if spec.family == "cartpole" or str(spec.gym_id).startswith("CartPole"):
        sync_cartpole_derived(inner)
    return env


def apply_wrappers(env: gym.Env, spec: TaskSpec, *, seed: int | None = None) -> gym.Env:
    """Compatible wrappers: same Box(4) obs and discrete(2) actions."""
    from nexus.tasks.wrappers import (
        AcrobotDenseRewardWrapper,
        ActionDelayWrapper,
        ContinuousMountainCarGravityPatch,
        MountainCarDenseRewardWrapper,
        DiscreteTorqueWrapper,
        ObservationNoiseWrapper,
    )

    delay = int(spec.params.get("action_delay", 0) or 0)
    noise = float(spec.params.get("obs_noise_std", 0.0) or 0.0)
    if delay > 0:
        env = ActionDelayWrapper(env, delay)
    if noise > 0:
        env = ObservationNoiseWrapper(env, noise, seed=0 if seed is None else int(seed) + 17)
    if spec.family == "pendulum" or "torque_neg" in spec.params:
        torques = (
            float(spec.params.get("torque_neg", -2.0)),
            float(spec.params.get("torque_zero", 0.0)),
            float(spec.params.get("torque_pos", 2.0)),
        )
        env = DiscreteTorqueWrapper(env, torques)
    if spec.family == "acrobot":
        env = AcrobotDenseRewardWrapper(env)
    if spec.family == "mountaincar":
        env = MountainCarDenseRewardWrapper(env)
    if spec.family == "mountaincar_continuous":
        env = ContinuousMountainCarGravityPatch(env, float(spec.params["gravity"]))
        env = DiscreteTorqueWrapper(env, (-1.0, 0.0, 1.0))
        env = MountainCarDenseRewardWrapper(env)
    return env


def make_task_env(spec: TaskSpec, *, seed: int | None = None, render_mode: str | None = None) -> gym.Env:
    make_kwargs: dict[str, Any] = {}
    if render_mode is not None:
        make_kwargs["render_mode"] = render_mode
    if spec.family in ("acrobot", "mountaincar", "mountaincar_continuous"):
        make_kwargs["max_episode_steps"] = 200
    env = gym.make(spec.gym_id, **make_kwargs)
    apply_params(env, spec)
    env = apply_wrappers(env, spec, seed=seed)
    if seed is not None:
        env.reset(seed=seed)
        env.action_space.seed(seed)
    return env


def task_env_fns(spec: TaskSpec, n_envs: int, seed: int) -> list[Callable[[], gym.Env]]:
    def _make(i: int) -> Callable[[], gym.Env]:
        def thunk() -> gym.Env:
            return make_task_env(spec, seed=seed + i)

        return thunk

    return [_make(i) for i in range(n_envs)]


def encode_obs(obs: np.ndarray, spec: TaskSpec) -> np.ndarray:
    """Identity encoder for Box observations in a compatible family."""
    arr = np.asarray(obs, dtype=np.float32).reshape(-1)
    if arr.size != spec.obs_dim:
        raise ValueError(f"obs dim {arr.size} != {spec.obs_dim} for {spec.task_id}")
    return arr
