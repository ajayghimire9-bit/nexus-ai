"""Explicitly authorized, bounded source-physics development return screen.

Reuses trained models, typed compositions, TaskSpec/wrappers and the original
ReservationLedger. No proposer training, checkpoint replacement or old gate
modification. Not the historical H16x16 controller or n=10 confirmation.
"""
from dataclasses import asdict
import gzip
import hashlib
import itertools
import json
import math
from pathlib import Path
import subprocess
import time

import numpy as np

from nexus.evolution1.catalogue import Rule, digest, plan_bound
from nexus.evolution1.resources import Work, Operation, Clock, Limits, ReservationLedger, model_work
from nexus.evolution1.toy_loop import ANCHORS
from nexus.evolution2.generated_strategies import leaf, compose, execute
from nexus.evolution2.persist_reset_path import disposable_model
from nexus.evolution2.fit_clock import LOCKED_ARRAYS
from nexus.tasks.spec import TaskSpec, make_task_env
from nexus.world.rewards import pendulum_step_reward, acrobot_step_reward

ROOT = Path(__file__).resolve().parents[3]
CONFIG = ROOT/"configs/unified_full_policy_source.json"
ALLOCATION = ROOT/"configs/unified_full_policy_source_allocation.json"
PROTOCOL = ROOT/"docs/NEXUS_UNIFIED_FULL_POLICY_SOURCE.md"
RESULT = ROOT/"artifacts/unified_full_policy_source.json"
JOURNAL = ROOT/"artifacts/unified_full_policy_resources.jsonl.gz"
USAGE = ROOT/"artifacts/unified_full_policy_usage.json"


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_file(path, expected):
    if sha(path)!=expected: raise ValueError("file_hash_mismatch")


def verify_checkpoints(rows,c):
    expected=set(itertools.product(c["families"],c["model_bundles"]))
    ids=[(r["family"],r["bundle"]) for r in rows]
    if len(ids)!=len(expected) or set(ids)!=expected:raise ValueError("checkpoint_grid")
    for r in rows:verify_file(ROOT/r["path"],r["sha256"])


def controllers():
    a,b = ANCHORS
    return {"flat_anchor":leaf(a),"successor_anchor":leaf(b),
            "switch":compose("switch",a,b,.25),"rank_blend":compose("rank_blend",a,b)}


def seeds(config,family,bundle,episode):
    f=config["families"].index(family)
    if config['version']=='crossed_reset_v1':bundle=0
    stride=4000 if config['version']=='coverage_feedback_v1' else (2000 if config['version']=='return_feedback_v1' else 1000)
    return (config["env_seed_base"]+f*10000+bundle*100+episode,
            config["planner_seed_base"]+f*10000+bundle*stride+episode*200)


def requested_seeds(c):
    env,planner=set(),set()
    for f,b,e in itertools.product(c["families"],c["model_bundles"],c["episodes"]):
        reset,base=seeds(c,f,b,e); env.add(reset)
        planner.update(range(base,base+c["episode_steps"]))
    units=len(c['families'])*len(c['model_bundles'])*len(c['episodes'])
    if c['version']=='crossed_reset_v1':units//=len(c['model_bundles'])
    if env & planner or len(env)!=units or len(planner)!=units*c['episode_steps']: raise ValueError("seed_schedule_collision")
    return env|planner


def seed_collisions(value,candidates):
    """Inspect integer seed metadata only; never return historical outcomes."""
    found=set()
    def visit(x,in_seed=False):
        if type(x) is dict:
            for k,v in x.items(): visit(v,in_seed or "seed" in str(k).lower())
        elif type(x) in (list,tuple):
            for v in x: visit(v,in_seed)
        elif in_seed and type(x) is int and x in candidates: found.add(x)
    visit(value)
    return found


def state_hash(model):
    h=hashlib.sha256()
    for name,t in sorted(model.net.state_dict().items()):
        a=t.detach().cpu().numpy(); h.update(name.encode()); h.update(str((a.shape,a.dtype)).encode()); h.update(a.tobytes())
    for name,v in sorted({**model.obs_rms.state_dict(),"epsilon":model.obs_rms.epsilon}.items()):
        a=np.asarray(v);h.update(name.encode());h.update(str((a.shape,a.dtype)).encode());h.update(a.tobytes())
    return h.hexdigest()


def operation_plan(strategy,obs,n_actions):
    ops=[]
    for v,cap in strategy.components(obs):
        n=plan_bound(v,n_actions,cap).candidates_per_root
        for _ in range(1 if v.rule is Rule.FLAT else n_actions):
            if v.rule is Rule.SUCCESSOR: ops.append(model_work((1,len(obs)),1))
            ops.extend(model_work((n,len(obs)),n) for _ in range(v.horizon))
    return tuple(Operation(f"model_{i}","model",cost) for i,cost in enumerate(ops)) + (Operation("environment","environment",Work(real_steps=1)),)


def task_spec(family):
    if family=="pendulum":
        return TaskSpec("unified_source_pendulum",family,"Pendulum-v1",3,3,
                        {"g":10.,"m":1.,"l":1.,"torque_neg":-2.,"torque_zero":0.,"torque_pos":2.})
    if family=="acrobot":
        return TaskSpec("unified_source_acrobot",family,"Acrobot-v1",6,3,
                        {"LINK_MASS_1":1.,"LINK_MASS_2":1.,"LINK_LENGTH_1":1.})
    raise ValueError("source_family_only")


def validate_config(c):
    expected={"version":"full_policy_source_v1","families":["pendulum","acrobot"],"model_bundles":[0,1],
      "episodes":[0,1],"controllers":["flat_anchor","successor_anchor","switch","rank_blend"],"episode_steps":200,
      "env_seed_base":2103000000,"planner_seed_base":2104000000,"imagined_per_decision":1536,
      "env_cap":6400,"imagined_cap":9830400,"time_cap_s":180,"practical_margin":1.0}
    replication={**expected,"version":"full_policy_replication_v1","episodes":[0,1,2,3],
        "controllers":["flat_anchor","successor_anchor","rank_blend"],"env_seed_base":2105000000,
        "planner_seed_base":2106000000,"env_cap":9600,"imagined_cap":14745600}
    crossed={**replication,'version':'crossed_reset_v1','families':['pendulum'],
        'controllers':['successor_anchor','rank_blend'],'env_seed_base':2107000000,
        'planner_seed_base':2108000000,'env_cap':3200,'imagined_cap':4915200,'time_cap_s':90}
    feedback={**replication,'version':'return_feedback_v1','episodes':list(range(7)),
        'controllers':['successor_anchor','rank_blend'],'env_seed_base':2111000000,
        'planner_seed_base':2112000000,'env_cap':11200,'imagined_cap':17203200}
    coverage={**feedback,'version':'coverage_feedback_v1','episodes':list(range(13)),
        'env_seed_base':2113000000,'planner_seed_base':2114000000,'env_cap':20800,
        'imagined_cap':31948800,'time_cap_s':240,'training_budgets':[3,6,9],'journal_chunk_decisions':4000}
    if json.dumps(c,sort_keys=True) not in [json.dumps(x,sort_keys=True) for x in (expected,replication,crossed,feedback,coverage)]:
        raise ValueError("locked_configuration_mismatch")


def run_paths(c):
    """Explicit locked profiles only, not an arbitrary experiment launcher."""
    validate_config(c)
    if c['version']=='full_policy_source_v1':
        return dict(config=CONFIG,allocation=ALLOCATION,protocol=PROTOCOL,result=RESULT,
                    journal=JOURNAL,usage=USAGE,previous=ROOT/'artifacts/unified_headroom_audit.json')
    if c['version']=='crossed_reset_v1':
        return {**{k:ROOT/p for k,p in {
            'config':'configs/unified_crossed_reset.json',
            'allocation':'configs/unified_crossed_reset_allocation.json',
            'protocol':'docs/NEXUS_UNIFIED_CROSSED_RESET_PROTOCOL.md',
            'result':'artifacts/unified_crossed_reset.json',
            'journal':'artifacts/unified_crossed_reset_resources.jsonl.gz',
            'usage':'artifacts/unified_crossed_reset_usage.json'}.items()},
            'previous':ROOT/'artifacts/unified_full_policy_replication_validation.json'}
    if c['version']=='return_feedback_v1':
        return {**{k:ROOT/p for k,p in {
            'config':'configs/e3_2_return_feedback.json','allocation':'configs/e3_2_return_feedback_allocation.json',
            'protocol':'docs/NEXUS_E3_2_RETURN_FEEDBACK_PROTOCOL.md','result':'artifacts/e3_2_return_feedback.json',
            'journal':'artifacts/e3_2_return_feedback_resources.jsonl.gz','usage':'artifacts/e3_2_return_feedback_usage.json'}.items()},
            'previous':ROOT/'artifacts/e3_1_learned_model_validation.json'}
    if c['version']=='coverage_feedback_v1':
        return {**{k:ROOT/p for k,p in {
            'config':'configs/e3_4_feedback_coverage.json','allocation':'configs/e3_4_feedback_coverage_allocation.json',
            'protocol':'docs/NEXUS_E3_4_FEEDBACK_COVERAGE_PROTOCOL.md','result':'artifacts/e3_4_feedback_coverage.json',
            'journal':'artifacts/e3_4_feedback_coverage_resources.jsonl.gz','usage':'artifacts/e3_4_feedback_coverage_usage.json'}.items()},
            'previous':ROOT/'artifacts/e3_3_training_feedback_validation.json'}
    return {**{key:ROOT/path for key,path in {
        'config':'configs/unified_full_policy_replication.json',
        'allocation':'configs/unified_full_policy_replication_allocation.json',
        'protocol':'docs/NEXUS_UNIFIED_FULL_POLICY_REPLICATION_PROTOCOL.md',
        'result':'artifacts/unified_full_policy_replication.json',
        'journal':'artifacts/unified_full_policy_replication_resources.jsonl.gz',
        'usage':'artifacts/unified_full_policy_replication_usage.json'}.items()},
        'previous':ROOT/'artifacts/unified_full_policy_validation.json'}


def validate_result(p,c):
    validate_config(c)
    expected=set(itertools.product(c["families"],c["model_bundles"],c["episodes"],c["controllers"]))
    rows=p["episodes"]
    ids=[(r["family"],r["model_bundle"],r["episode"],r["controller"]) for r in rows]
    if len(ids)!=len(expected) or set(ids)!=expected: raise ValueError("incomplete_episode_grid")
    for r in rows:
        if type(r["model_bundle"]) is not int or type(r["episode"]) is not int: raise ValueError("invalid_identity")
        if len(r["steps"])!=200 or [s["tick"] for s in r["steps"]]!=list(range(200)): raise ValueError("incomplete_step_grid")
        if any(type(s["reward"]) not in (int,float) or not math.isfinite(s["reward"]) for s in r["steps"]): raise ValueError("invalid_reward")
        if type(r["return"]) not in (int,float) or not math.isfinite(r["return"]):raise ValueError("invalid_return")
        if not math.isclose(sum(s["reward"] for s in r["steps"]),r["return"],abs_tol=1e-9): raise ValueError("reward_accounting")
        reset,base=seeds(c,r["family"],r["model_bundle"],r["episode"])
        if r["reset_seed"]!=reset or r["planner_base"]!=base:raise ValueError("seed_pairing")
        for i,s in enumerate(r["steps"]):
            if s["planner_seed"]!=base+i:raise ValueError("planner_pairing")
            if type(s["action"]) is not int or s["action"] not in range(3):raise ValueError("action_index")
            size=3 if r["family"]=="pendulum" else 6
            for key in ("obs","next_obs"):
                if np.asarray(s[key]).shape!=(size,) or not np.isfinite(s[key]).all():raise ValueError("observation_schema")
            if i and s["obs"]!=r["steps"][i-1]["next_obs"]:raise ValueError("transition_continuity")
            if s["terminated"] is not False or s["truncated"] is not (i==199):raise ValueError("termination_schedule")
        if digest(r["steps"][0]["obs"])!=r["initial_obs_hash"]:raise ValueError("initial_state_hash")
    if p["resources"]["completed"]["real_steps"]!=c['env_cap'] or p["resources"]["unknown_upper"]!={k:0 for k in Work().payload()}:
        raise ValueError("incomplete_resource_work")
    for f,b,e in itertools.product(c["families"],c["model_bundles"],c["episodes"]):
        group=[r for r in rows if (r["family"],r["model_bundle"],r["episode"])==(f,b,e)]
        if len({r["initial_obs_hash"] for r in group})!=1 or len({r["reset_seed"] for r in group})!=1:
            raise ValueError("unpaired_reset")
    if c['version']=='crossed_reset_v1':
        for e in c['episodes']:
            group=[r for r in rows if r['episode']==e]
            if len({r['initial_obs_hash'] for r in group})!=1:raise ValueError('uncrossed_initial_states')
    return True


def analyze(rows,c):
    contrasts={}
    anchors=[a for a in ('flat_anchor','successor_anchor') if a in c['controllers']]
    for f in c["families"]:
        family={}
        for generated in (g for g in c['controllers'] if g not in ('flat_anchor','successor_anchor')):
            checks={}
            for anchor in anchors:
                pairs=[]
                for b in c["model_bundles"]:
                    diffs=[]
                    for e in c["episodes"]:
                        values={r["controller"]:r["return"] for r in rows if (r["family"],r["model_bundle"],r["episode"])==(f,b,e)}
                        diffs.append(values[generated]-values[anchor])
                    pairs.append(sum(diffs)/len(diffs))
                checks[anchor]={"per_model":pairs,"mean":sum(pairs)/len(pairs),
                    "point_screen":sum(pairs)/len(pairs)>=c["practical_margin"] and all(x>0 for x in pairs)}
            family[generated]=checks
        contrasts[f]=family
    generated=[g for g in c['controllers'] if g not in ('flat_anchor','successor_anchor')]
    passed={g:all(contrasts[f][g][a]["point_screen"] for f in c["families"] for a in anchors) for g in generated}
    return {"paired_contrasts":contrasts,"point_screen_by_generated":passed,
            "scientific_control_success":False,"independent_model_count_per_family":2,
            "intervals":"Not reported: exploratory n=2 source-model pairs per family; no ten-decoder inference."}


def training_episodes(c):return tuple(range(9 if c['version']=='coverage_feedback_v1' else 3))


def evaluation_episodes(c):return tuple(range(9,13) if c['version']=='coverage_feedback_v1' else range(3,7))


def model_jobs(c,selected):
    stages=[('training',training_episodes(c)),('evaluation',evaluation_episodes(c))] if c['version'] in ('return_feedback_v1','coverage_feedback_v1') else [('evaluation',c['episodes'])]
    return [(r,stage,episodes) for stage,episodes in stages for r in selected]


class DecisionJournal:
    """Lossless physical journal rotation; no resource-meter changes."""
    def __init__(self,path,chunk_decisions=None):
        self.path=path;self.chunk=chunk_decisions;self.paths=[];self.stream=None;self.n=0
    def __enter__(self):return self
    def write(self,data):
        if self.stream is None or (self.chunk and self.n%self.chunk==0):
            if self.stream:self.stream.close()
            p=self.path if not self.chunk else self.path.with_name(self.path.name.replace('.jsonl.gz',f'.part{len(self.paths):02}.jsonl.gz'))
            self.stream=gzip.open(p,'xb');self.paths.append(p)
        self.stream.write(data);self.n+=1
    def __exit__(self,*args):
        if self.stream:self.stream.close()


def run(c, *, on_training=None, on_decision=None):
    validate_config(c)
    feedback=c['version'] in ('return_feedback_v1','coverage_feedback_v1')
    if feedback and (on_training is None or on_decision is None):raise ValueError('feedback_hooks_required')
    if not feedback and (on_training is not None or on_decision is not None):raise ValueError('unexpected_hooks')
    paths=run_paths(c)
    config_path,allocation_path,protocol_path=paths['config'],paths['allocation'],paths['protocol']
    result_path,journal_path,usage_path=paths['result'],paths['journal'],paths['usage']
    t0,cpu0=time.perf_counter(),time.process_time()
    deadline=t0+c["time_cap_s"]
    old={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/"artifacts").rglob("*.json") if p not in (result_path,usage_path)}
    allocation=json.loads(allocation_path.read_text())
    if allocation["config_sha256"]!=sha(config_path) or allocation["protocol_sha256"]!=sha(protocol_path) or not allocation["authorized"]:
        raise ValueError("allocation_integrity")
    if allocation["time_cap_s"]!=c["time_cap_s"] or allocation["env_cap"]!=c["env_cap"] or allocation["imagined_cap"]!=c["imagined_cap"]:
        raise ValueError("allocation_cap_mismatch")
    if usage_path.exists() or journal_path.exists() or result_path.exists() or (c.get('journal_chunk_decisions') and list(journal_path.parent.glob(journal_path.name.replace('.jsonl.gz','.part*.jsonl.gz')))):
        raise FileExistsError("one_run_already_started")
    with usage_path.open("x") as use:
        use.write(json.dumps({"consumed":True,"allocation_sha256":sha(allocation_path),"automatic_retry":False})+"\n")
    state={"reserved":Work(),"completed":Work(),"unknown_upper":Work()}
    limits=Work(real_steps=c["env_cap"],imagined_transitions=c["imagined_cap"],model_calls=c['env_cap']*67,network_forwards=c['env_cap']*67)
    p={"declared_complete":False,"development_only":True,"episodes":[],"models":[],"resources":{},
       "config":c,"historical_artifacts_sha256":old,"authorization":allocation}
    clock=lambda:Clock(int((time.process_time()-cpu0)*1e9),int((time.perf_counter()-t0)*1e9))
    journal=None
    try:
        if c['version']!='full_policy_source_v1':
            for name,expected in allocation['parent_artifacts_sha256'].items():verify_file(ROOT/name,expected)
        previous=json.loads(paths['previous'].read_text())
        if previous['session_ledger']['used_after_s']!=allocation['session_used_before_s']:
            raise ValueError('session_ledger_mismatch')
        if previous['session_ledger']['used_after_s']+c['time_cap_s']>3600:raise ValueError('session_budget')
        candidates=requested_seeds(c)
        collisions={name:sorted(seed_collisions(json.loads((ROOT/name).read_text()),candidates)) for name in old}
        collisions={k:v for k,v in collisions.items() if v}
        registry=json.loads((ROOT/"artifacts/h17_exclusion_registry_audit_validated.json").read_text())
        if collisions or any(lo<=s<=hi for s in candidates for lo,hi in registry["conservative_seed_reservations"]):
            raise ValueError("historical_seed_collision")
        p["seed_audit"]={"historical_json_count":len(old),"explicit_seed_collisions":collisions,
            "conservative_h17_ranges_disjoint":True,"planned_unique_seed_count":len(candidates),
            "scope":"Reachable-tree seed metadata and preserved historical registry, not unavailable external runs."}
        manifest=json.loads((ROOT/"artifacts/evolution2_fit_clock_run.json").read_text())
        selected=[r for r in manifest["fits"] if r["bundle"] in c["model_bundles"] and r['family'] in c['families']]
        verify_checkpoints(selected,c)
        p["source_arrays"]=[r for r in LOCKED_ARRAYS if r["bundle"] in c["model_bundles"] and r['family'] in c['families']]
        for r in p["source_arrays"]:
            verify_file(ROOT/r["path"],r["sha256"])
            with np.load(ROOT/r["path"]) as source:
                if set(source["env_seeds"].reshape(-1).tolist()) & candidates:raise ValueError("source_episode_seed_collision")
        p["fit_manifest_sha256"]=sha(ROOT/"artifacts/evolution2_fit_clock_run.json")
        jobs=model_jobs(c,selected)
        fitted=False;decisions={}
        with DecisionJournal(journal_path,c.get('journal_chunk_decisions')) as journal:
            for r,stage,episodes in jobs:
                if time.perf_counter()>=deadline:raise TimeoutError("time_cap")
                if feedback and stage=='evaluation' and not fitted:
                    on_training(tuple(p['episodes']));fitted=True
                    if time.perf_counter()>=deadline:raise TimeoutError('time_cap')
                f,b=r["family"],r["bundle"]
                model=disposable_model(f,b)
                if (str(model.device)!="cpu" or model.net.arch!="mlp" or model.kind!="residual"
                    or tuple(model.net.hidden)!=(64,64) or model.net.obs_dim!=task_spec(f).obs_dim or model.net.n_actions!=3):
                    raise ValueError("frozen_cpu_residual_mlp_required")
                model.net.eval()
                for param in model.net.parameters():param.requires_grad_(False)
                fingerprint=state_hash(model)
                if c['version']!='full_policy_source_v1':
                    parent=json.loads(RESULT.read_text())
                    original=next(x for x in parent['models'] if (x['family'],x['bundle'])==(f,b))
                    if fingerprint!=original['before']:raise ValueError('parent_frozen_state_mismatch')
                for e in episodes:
                    reset,planner=seeds(c,f,b,e)
                    for label in c['controllers']:
                        strategy=controllers()[label]
                        if time.perf_counter()>=deadline:raise TimeoutError("time_cap")
                        env=make_task_env(task_spec(f),seed=reset)
                        obs,_=env.reset(seed=reset)
                        if feedback and stage=='evaluation':
                            key=(f,b,e)
                            if key not in decisions:
                                decisions[key]=on_decision(dict(family=f,model_bundle=b,episode=e,initial_obs=np.asarray(obs).tolist(),
                                    completed_real_steps=state['completed'].real_steps))
                                p.setdefault('selection_decisions',[]).append(decisions[key])
                        episode={"family":f,"model_bundle":b,"episode":e,"controller":label,"reset_seed":reset,
                                 "planner_base":planner,"initial_obs_hash":digest(np.asarray(obs).tolist()),"steps":[],"return":0.}
                        p["episodes"].append(episode)
                        if feedback:episode['split']=stage
                        try:
                            for tick in range(c["episode_steps"]):
                                ops=operation_plan(strategy,obs,3)
                                upper=Work()
                                for op in ops:upper=upper.plus(op.cost)
                                if not state["reserved"].plus(upper).fits(limits): raise RuntimeError("global_work_cap")
                                ledger=ReservationLedger(ops,Limits(upper,upper,int(c["time_cap_s"]*1e9),int(c["time_cap_s"]*1e9)))
                                cursor=[0]
                                class MeteredModel:
                                    def step(self,o,a):
                                        if time.perf_counter()>=deadline:raise TimeoutError("time_cap")
                                        op=ops[cursor[0]]
                                        actual=model_work(np.asarray(o).reshape(-1,len(obs)).shape,int(np.asarray(a).size))
                                        if actual!=op.cost:raise ValueError("unplanned_model_call")
                                        ticket=ledger.reserve(op.key,clock());state["reserved"]=state["reserved"].plus(op.cost)
                                        try:out=model.step(o,a)
                                        except BaseException:ledger.settle(ticket,"interrupted",clock());raise
                                        ledger.settle(ticket,"success",clock());cursor[0]+=1
                                        return out
                                try:
                                    start=time.perf_counter()
                                    action=execute(strategy,f,obs,MeteredModel(),seed=planner+tick)
                                    latency=time.perf_counter()-start
                                    if cursor[0]!=len(ops)-1:raise ValueError("model_call_plan_incomplete")
                                    if time.perf_counter()>=deadline:raise TimeoutError("time_cap")
                                    ticket=ledger.reserve("environment",clock())
                                    state["reserved"]=state["reserved"].plus(Work(real_steps=1))
                                    try:nxt,reward,terminated,truncated,info=env.step(action)
                                    except BaseException:ledger.settle(ticket,"interrupted",clock());raise
                                    ledger.settle(ticket,"success",clock())
                                    published=pendulum_step_reward(obs,action,nxt) if f=="pendulum" else acrobot_step_reward(obs,action,nxt)
                                    # Gym's hidden float64 state is observed as float32.
                                    if not math.isclose(float(published[0]),float(reward),abs_tol=1e-5):raise ValueError("reward_timing_mismatch")
                                    episode["steps"].append({"tick":tick,"obs":np.asarray(obs).tolist(),"action":int(action),"reward":float(reward),
                                        "next_obs":np.asarray(nxt).tolist(),"planner_seed":planner+tick,"planning_s":latency,
                                        "terminated":bool(terminated),"truncated":bool(truncated)})
                                    episode["return"]+=float(reward);obs=nxt
                                finally:
                                    report=ledger.close(clock())
                                    state["completed"]=state["completed"].plus(report.physical_completed_reported)
                                    state["unknown_upper"]=state["unknown_upper"].plus(report.physical_unknown_upper_bound)
                                    journal.write((json.dumps({"family":f,"model":b,"episode":e,"controller":label,"tick":tick,
                                        "events":[asdict(x) for x in report.events],"status":report.status})+"\n").encode())
                                if report.status!="complete_execution":raise RuntimeError("incomplete_decision")
                                if terminated or truncated:
                                    if tick!=199:raise ValueError("unexpected_early_termination")
                                    break
                        finally:env.close()
                after=state_hash(model)
                if after!=fingerprint or sha(ROOT/r["path"])!=r["sha256"]:raise ValueError("frozen_model_changed")
                known=next((x for x in p['models'] if (x['family'],x['bundle'])==(f,b)),None)
                if known is None:p['models'].append({**r,"before":fingerprint,"after":after})
                elif known['before']!=fingerprint or known['after']!=after:raise ValueError('phase_model_state_changed')
        p["resources"]={k:v.payload() for k,v in state.items()}
        validate_result(p,c)
        p["analysis"]=analyze(p["episodes"],c)
        if any(sha(ROOT/n)!=h for n,h in old.items()):raise ValueError("history_changed")
        if time.perf_counter()>=deadline:raise TimeoutError("time_cap")
        p["declared_complete"]=True
    except (Exception,KeyboardInterrupt) as exc:p["failure"]=f"{type(exc).__name__}: {exc}"
    p["resources"]={**{k:v.payload() for k,v in state.items()},"wall_s":time.perf_counter()-t0,"cpu_s":time.process_time()-cpu0}
    if c.get('journal_chunk_decisions'):
        p['resource_journal_parts']=[dict(path=str(path.relative_to(ROOT)),sha256=sha(path)) for path in (journal.paths if journal else [])]
    elif journal_path.exists():p["resource_journal_sha256"]=sha(journal_path)
    start=allocation['session_used_before_s']
    p["session_ledger"]={"used_before_s":start,"used_after_s":start+p["resources"]["wall_s"],"remaining_after_s":3600-start-p["resources"]["wall_s"]}
    return p
